﻿using dataCRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace dataCRUD.Controllers
{
    public class HomeController : Controller
    {
        private MyDatabaseEntities db = new MyDatabaseEntities();
        public ActionResult Display()
        {
            Employee e1 = new Employee();
            return View(e1);
        }
        public ActionResult Listt()
        {
            return View(db.Employees.ToList());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include ="Id,Name,EmailId,city,country")] Employee e2)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(e2);
                db.SaveChanges();
                return RedirectToAction("Listt");
            }
 
            return View(e2);
        }
    }
}